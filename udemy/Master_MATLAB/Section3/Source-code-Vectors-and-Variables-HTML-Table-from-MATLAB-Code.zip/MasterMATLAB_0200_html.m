%% 
%     COURSE: Master MATLAB through guided problem-solving
%    SECTION: Vectors and variables
%      VIDEO: html table from MATLAB code
% Instructor: mikexcohen.com
%
%%


% generate some random numbers and characters
N = 20; % 20 number/character pairs
numbers = 
tmptext = char( 


% clear the screen to facilitate copy/paste
clc

% html code for header
disp('<html>')
disp('<body>')

% html code for table
disp('<table>')

% loop over elements and print
for ri=1:N
    disp([ 
end

% close html
fprintf(

%%


%% 
%     COURSE: Master MATLAB through guided problem-solving
%    SECTION: Vectors and variables
%      VIDEO: Create vectors and matrices
% Instructor: mikexcohen.com
%
%%

% make a row vector using square brackets
vect = 

% make a column vector using semicolons
vect = 

% make a column vector by transposing a row vector
vect = 

% create a 2x3 matrix
matr = 

% or transpose a 3x2 matrix!


% make a row vector of ones


% column vector of .25


% matrix of random numbers
matr = 

% transpose that matrix and store as a new matrix

%%

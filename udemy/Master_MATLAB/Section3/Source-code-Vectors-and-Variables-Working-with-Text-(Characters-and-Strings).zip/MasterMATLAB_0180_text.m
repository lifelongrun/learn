%% 
%     COURSE: Master MATLAB through guided problem-solving
%    SECTION: Vectors and variables
%      VIDEO: Working with text (characters and strings)
% Instructor: mikexcohen.com
%
%%

wholetext = 'Hello my name is Mike and I like purple.';

% separate into a cell array based on spaces
wordsep = regexp(

% remove any words with exactly 4 characters
numchars   = cellfun
words2keep = 


% replace 'Mike' with your name and 'purple' with your favorite color
targname  = 'Mike';
targcolor = 'purple';

%%
